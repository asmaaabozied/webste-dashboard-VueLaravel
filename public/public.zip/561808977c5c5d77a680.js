(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[30],{

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n[data-v-8e2009f2] .v-card__text {\n    padding: 5px 16px !important;\n}\n[data-v-8e2009f2] .v-card__title{\n    word-break: break-word\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../node_modules/css-loader??ref--6-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./resources/js/pages/Customer/products/products.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/pages/Customer/products/products.vue + 4 modules ***!
  \***********************************************************************/
/*! exports provided: default */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/@mdi/js/mdi.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vue-loader/lib/runtime/componentNormalizer.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify-loader/lib/runtime/installComponents.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VBadge/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VBtn/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCard/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCarousel/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VDialog/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VGrid/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VIcon/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VImg/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VProgressCircular/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VTextField/index.js */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/products/products.vue?vue&type=template&id=8e2009f2&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("v-row", { staticClass: "my-1", attrs: { justify: "center" } }, [
        _c(
          "div",
          { staticClass: "ad-container", staticStyle: { width: "1000px" } },
          [
            _c(
              "v-carousel",
              {
                attrs: {
                  height: "100%",
                  cycle: "",
                  "hide-delimiters": "",
                  "show-arrows": false
                }
              },
              _vm._l(_vm.internalAds, function(item, i) {
                return _c("v-carousel-item", {
                  key: i,
                  attrs: { src: item.image, transition: "fade-transition" }
                })
              }),
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c(
        "v-row",
        { staticClass: "mx-12 px-12 my-4", attrs: { justify: "center" } },
        [
          _c("div", { staticStyle: { width: "20vw" } }),
          _vm._v(" "),
          _c("v-spacer"),
          _vm._v(" "),
          _vm.$isLoggedin && _vm.$roleEquals("customer")
            ? _c(
                "v-btn",
                {
                  attrs: { icon: "", loading: _vm.isLoadingCart },
                  on: {
                    click: function($event) {
                      _vm.cartDialog = true
                    }
                  }
                },
                [
                  _c(
                    "v-badge",
                    {
                      attrs: {
                        content: _vm.cart.length,
                        value: _vm.cart.length,
                        color: "grey lighten-1"
                      }
                    },
                    [
                      _vm.cart.length > 0
                        ? _c("v-icon", { attrs: { color: "blue" } }, [
                            _vm._v(_vm._s(_vm.icons.mdiCart))
                          ])
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.cart.length == 0
                        ? _c("v-icon", [
                            _vm._v(_vm._s(_vm.icons.mdiCartOutline))
                          ])
                        : _vm._e()
                    ],
                    1
                  )
                ],
                1
              )
            : _vm._e()
        ],
        1
      ),
      _vm._v(" "),
      _vm.isLoading
        ? _c(
            "div",
            {
              staticClass: "text-center",
              staticStyle: { height: "50vh" },
              attrs: { width: "100%" }
            },
            [
              _c("v-progress-circular", {
                attrs: {
                  width: 7,
                  size: 70,
                  color: "primary",
                  indeterminate: ""
                }
              })
            ],
            1
          )
        : _c(
            "v-row",
            { staticClass: "d-flex justify-start flex-wrap mx-8" },
            _vm._l(_vm.items, function(item, i) {
              return _c(
                "v-col",
                { key: i, attrs: { md: "6", sm: "6", lg: "3", cols: "12" } },
                [
                  _c(
                    "v-card",
                    {
                      staticStyle: {
                        "border-radius": "20px",
                        "min-height": "400px"
                      },
                      attrs: { width: "100%" }
                    },
                    [
                      _c("v-img", {
                        attrs: { height: "200", src: item.image }
                      }),
                      _vm._v(" "),
                      _c(
                        "div",
                        { staticClass: "d-flex justify-lg-space-between" },
                        [
                          _c(
                            "v-card-title",
                            { staticStyle: { "font-size": "16px" } },
                            [
                              _vm._v(
                                _vm._s(
                                  _vm.$i18n.locale == "en"
                                    ? item.name
                                    : item.name_ar
                                ) + "\n                    "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "v-card-title",
                            { staticStyle: { "font-size": "16px" } },
                            [
                              _vm._v(
                                _vm._s(
                                  item.price + " " + _vm.$t("general.sar")
                                ) + "\n                    "
                              )
                            ]
                          )
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("v-card-text", [
                        _vm._v(
                          "\n                    " +
                            _vm._s(
                              _vm.$i18n.locale == "en"
                                ? item.description
                                : item.description_ar
                            ) +
                            "\n                "
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "label",
                            { staticStyle: { "font-size": "18px" } },
                            [_vm._v(_vm._s(_vm.$t("general.quantity")))]
                          ),
                          _vm._v(" "),
                          _c("v-text-field", {
                            attrs: {
                              type: "number",
                              min: "0",
                              autocorrect: "off",
                              autocapitalize: "off",
                              spellcheck: "false",
                              autocomplete: "off",
                              rules: [
                                function(v) {
                                  return !!v || _vm.$requiredRules
                                }
                              ],
                              readonly: item.isAdded,
                              outlined: "",
                              dense: ""
                            },
                            model: {
                              value: item.cartQuantity,
                              callback: function($$v) {
                                _vm.$set(item, "cartQuantity", $$v)
                              },
                              expression: "item.cartQuantity"
                            }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "v-card-actions",
                        { staticClass: "d-flex justify-center" },
                        [
                          _vm.$isLoggedin && !item.isAdded
                            ? _c(
                                "v-btn",
                                {
                                  attrs: {
                                    rounded: "",
                                    color: "primary",
                                    loading: item.isLoading
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.addToCart(item)
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    _vm._s(_vm.$t("general.add")) +
                                      "\n                    "
                                  )
                                ]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          !_vm.$isLoggedin
                            ? _c(
                                "v-btn",
                                {
                                  attrs: {
                                    rounded: "",
                                    color: "primary",
                                    loading: item.isLoading
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.redirectIfNotLoggedIn()
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    _vm._s(_vm.$t("general.add")) +
                                      "\n                    "
                                  )
                                ]
                              )
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.$isLoggedin && item.isAdded
                            ? _c(
                                "v-btn",
                                {
                                  attrs: { text: "", loading: item.isLoading },
                                  on: {
                                    click: function($event) {
                                      return _vm.removeFromCart(item)
                                    }
                                  }
                                },
                                [
                                  _vm._v(
                                    _vm._s(_vm.$t("general.remove")) +
                                      "\n                    "
                                  )
                                ]
                              )
                            : _vm._e()
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            }),
            1
          ),
      _vm._v(" "),
      _vm.$isLoggedin && _vm.$roleEquals("customer")
        ? _c(
            "v-dialog",
            {
              attrs: { width: "50vw", scrollable: "" },
              model: {
                value: _vm.cartDialog,
                callback: function($$v) {
                  _vm.cartDialog = $$v
                },
                expression: "cartDialog"
              }
            },
            [
              _c(
                "v-card",
                { attrs: { "min-height": "30vh" } },
                [
                  _c("v-card-title", [
                    _vm._v(_vm._s(_vm.$t("general.cartContent")))
                  ]),
                  _vm._v(" "),
                  _c("v-card-text", [
                    _vm.$isLoggedin
                      ? _c(
                          "div",
                          { staticClass: "d-flex flex-column" },
                          _vm._l(_vm.cart, function(item, i) {
                            return _c(
                              "div",
                              { key: i, staticClass: "ma-2" },
                              [
                                _c(
                                  "v-card",
                                  { attrs: { outlined: "", width: "100%" } },
                                  [
                                    _c(
                                      "v-card-actions",
                                      { staticClass: "d-flex justify-end" },
                                      [
                                        _c(
                                          "v-btn",
                                          {
                                            attrs: { icon: "" },
                                            on: {
                                              click: function($event) {
                                                return _vm.removeFromCart({
                                                  id: item.product.id
                                                })
                                              }
                                            }
                                          },
                                          [
                                            _c(
                                              "v-icon",
                                              { attrs: { color: "red" } },
                                              [
                                                _vm._v(
                                                  _vm._s(_vm.icons.mdiClose)
                                                )
                                              ]
                                            )
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "v-row",
                                      { attrs: { "no-gutters": "" } },
                                      [
                                        _c(
                                          "v-col",
                                          { attrs: { cols: "4" } },
                                          [
                                            _c("v-img", {
                                              attrs: { src: item.product.image }
                                            })
                                          ],
                                          1
                                        ),
                                        _vm._v(" "),
                                        _c(
                                          "v-col",
                                          { attrs: { cols: "8" } },
                                          [
                                            _c("v-card-title", [
                                              _vm._v(
                                                _vm._s(item.product.model_code)
                                              )
                                            ]),
                                            _vm._v(" "),
                                            _c("v-card-text", [
                                              _c(
                                                "div",
                                                { staticClass: "mt-1" },
                                                [
                                                  _vm._v(
                                                    _vm._s(
                                                      _vm.$i18n.locale == "en"
                                                        ? item.product.name
                                                        : item.product.name_ar
                                                    ) +
                                                      "\n                                        "
                                                  )
                                                ]
                                              ),
                                              _vm._v(" "),
                                              _c("div", [
                                                _vm._v(
                                                  _vm._s(
                                                    _vm.$t("general.quantity") +
                                                      " : " +
                                                      item.quantity
                                                  )
                                                )
                                              ]),
                                              _vm._v(" "),
                                              _c("div", [
                                                _vm._v(
                                                  _vm._s(
                                                    _vm.$t("general.price") +
                                                      " : " +
                                                      item.product.price +
                                                      " " +
                                                      _vm.$t("general.sar")
                                                  ) +
                                                    "\n                                        "
                                                )
                                              ])
                                            ])
                                          ],
                                          1
                                        )
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          }),
                          0
                        )
                      : _vm._e()
                  ]),
                  _vm._v(" "),
                  _c(
                    "v-card-actions",
                    [
                      _c("span", [
                        _vm._v(
                          _vm._s(
                            _vm.$t("transactions.total") +
                              " : " +
                              _vm.total +
                              " " +
                              _vm.$t("general.sar")
                          )
                        )
                      ]),
                      _vm._v(" "),
                      _c("v-spacer"),
                      _vm._v(" "),
                      _c(
                        "v-btn",
                        {
                          attrs: { outlined: "", text: "" },
                          on: {
                            click: function($event) {
                              _vm.cartDialog = false
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("general.close")))]
                      ),
                      _vm._v(" "),
                      _vm.cart.length > 0
                        ? _c(
                            "v-btn",
                            {
                              staticClass: "white--text",
                              attrs: { color: "green" },
                              on: {
                                click: function($event) {
                                  return _vm.makeTransaction()
                                }
                              }
                            },
                            [
                              _vm._v(
                                "\n                    " +
                                  _vm._s(
                                    _vm.$t("transactions.makeTransaction")
                                  ) +
                                  "\n                "
                              )
                            ]
                          )
                        : _vm._e()
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _c("v-row", { staticClass: "my-1", attrs: { justify: "center" } }, [
        _c("div", { staticClass: "ad-container" })
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/Customer/products/products.vue?vue&type=template&id=8e2009f2&scoped=true&

// EXTERNAL MODULE: ./node_modules/@mdi/js/mdi.js
var mdi = __webpack_require__("./node_modules/@mdi/js/mdi.js");

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/products/products.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var productsvue_type_script_lang_js_ = ({
  name: "Products",
  data: function data() {
    return {
      icons: {
        mdiCart: mdi["mdiCart"],
        mdiCartOutline: mdi["mdiCartOutline"],
        mdiClose: mdi["mdiClose"]
      },
      searchText: null,
      internalAds: [],
      cartDialog: false,
      cart: [],
      items: [],
      isLoading: false,
      isLoadingCart: false,
      total: 0
    };
  },
  created: function created() {
    this.loadProducts();
    this.loadAds();
  },
  mounted: function mounted() {
    if (this.$isLoggedin) {
      this.loadCart();
    }
  },
  methods: {
    loadProducts: function loadProducts() {
      var _this = this;

      this.isLoading = true;
      axios.get("/api/product").then(function (res) {
        _this.items = res.data.data;
      })["catch"](function (err) {
        console.warn(err);
      })["finally"](function () {
        _this.isLoading = false;
      });
    },
    loadAds: function loadAds() {
      var _this2 = this;

      axios.get("/api/advertArea").then(function (res) {
        _this2.internalAds = res.data.data.resource.data;
      })["catch"](function (err) {
        console.warn(err);
      });
    },
    loadCart: function loadCart() {
      var _this3 = this;

      if (this.$isLoggedin && this.$roleEquals('customer')) {
        this.isLoadingCart = true;
        axios.get("/api/getCart").then(function (res) {
          _this3.cart = res.data.data.cart;

          _this3.items.forEach(function (element) {
            for (var i = 0; i < _this3.cart.length; i++) {
              if (_this3.cart[i].product_id == element.id) element["isAdded"] = true;
            }
          });

          _this3.total = res.data.data.total;
        })["catch"](function (err) {
          console.warn(err);
        })["finally"](function () {
          _this3.isLoadingCart = false;
        });
      }
    },
    addToCart: function addToCart(item) {
      var _this4 = this;

      if (!this.$roleEquals('customer')) {
        this.$notify({
          text: this.$t('general.customerOnly'),
          type: "warning"
        });
        return;
      }

      if (item.cartQuantity > 0) {
        item.isLoading = true;
        axios.post("/api/addProductToCart", {
          product_id: item.id,
          quantity: item.cartQuantity
        }).then(function (res) {
          _this4.loadCart();
        })["catch"](function (err) {})["finally"](function () {
          item.isLoading = false;
        });
      }
    },
    removeFromCart: function removeFromCart(item) {
      var _this5 = this;

      item.isLoading = true;
      console.log(item);
      axios["delete"]("/api/removeProductFromCart", {
        headers: {
          Authorization: "Bearer " + this.$store.state.token
        },
        data: {
          product_id: item.id
        }
      }).then(function (res) {
        item.isAdded = false;

        _this5.loadProducts();
      })["catch"](function (err) {
        console.warn(err);
      })["finally"](function () {
        item.isLoading = false;

        _this5.loadCart();
      });
    },
    makeTransaction: function makeTransaction() {
      var _this6 = this;

      axios.post("/api/makeTransaction/product", {
        delivery_method: 1
      }).then(function (res) {
        _this6.showSuccessMessage(_this6.$t('transactions.success'));

        _this6.$router.push({
          name: "c19"
        });
      })["catch"](function (err) {
        console.warn(err);
      });
    }
  }
});
// CONCATENATED MODULE: ./resources/js/pages/Customer/products/products.vue?vue&type=script&lang=js&
 /* harmony default export */ var products_productsvue_type_script_lang_js_ = (productsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&
var productsvue_type_style_index_0_id_8e2009f2_scoped_true_lang_css_ = __webpack_require__("./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

// EXTERNAL MODULE: ./node_modules/vuetify-loader/lib/runtime/installComponents.js
var installComponents = __webpack_require__("./node_modules/vuetify-loader/lib/runtime/installComponents.js");
var installComponents_default = /*#__PURE__*/__webpack_require__.n(installComponents);

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VBadge/index.js + 1 modules
var VBadge = __webpack_require__("./node_modules/vuetify/lib/components/VBadge/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VBtn/index.js
var VBtn = __webpack_require__("./node_modules/vuetify/lib/components/VBtn/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCard/index.js + 1 modules
var VCard = __webpack_require__("./node_modules/vuetify/lib/components/VCard/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCarousel/index.js + 2 modules
var VCarousel = __webpack_require__("./node_modules/vuetify/lib/components/VCarousel/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VGrid/index.js + 7 modules
var VGrid = __webpack_require__("./node_modules/vuetify/lib/components/VGrid/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VDialog/index.js
var VDialog = __webpack_require__("./node_modules/vuetify/lib/components/VDialog/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VIcon/index.js
var VIcon = __webpack_require__("./node_modules/vuetify/lib/components/VIcon/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VImg/index.js
var VImg = __webpack_require__("./node_modules/vuetify/lib/components/VImg/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VProgressCircular/index.js
var VProgressCircular = __webpack_require__("./node_modules/vuetify/lib/components/VProgressCircular/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VTextField/index.js
var VTextField = __webpack_require__("./node_modules/vuetify/lib/components/VTextField/index.js");

// CONCATENATED MODULE: ./resources/js/pages/Customer/products/products.vue






/* normalize component */

var component = Object(componentNormalizer["default"])(
  products_productsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "8e2009f2",
  null
  
)

/* vuetify-loader */

















installComponents_default()(component, {VBadge: VBadge["VBadge"],VBtn: VBtn["VBtn"],VCard: VCard["VCard"],VCardActions: VCard["VCardActions"],VCardText: VCard["VCardText"],VCardTitle: VCard["VCardTitle"],VCarousel: VCarousel["VCarousel"],VCarouselItem: VCarousel["VCarouselItem"],VCol: VGrid["VCol"],VDialog: VDialog["VDialog"],VIcon: VIcon["VIcon"],VImg: VImg["VImg"],VProgressCircular: VProgressCircular["VProgressCircular"],VRow: VGrid["VRow"],VSpacer: VGrid["VSpacer"],VTextField: VTextField["VTextField"]})


/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Customer/products/products.vue"
/* harmony default export */ var products = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&":
/*!********************************************************************************************************************!*\
  !*** ./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css& ***!
  \********************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module exports are unknown */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_products_vue_vue_type_style_index_0_id_8e2009f2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader!../../../../../node_modules/css-loader??ref--6-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/products/products.vue?vue&type=style&index=0&id=8e2009f2&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_products_vue_vue_type_style_index_0_id_8e2009f2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_products_vue_vue_type_style_index_0_id_8e2009f2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_products_vue_vue_type_style_index_0_id_8e2009f2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_products_vue_vue_type_style_index_0_id_8e2009f2_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ })

}]);