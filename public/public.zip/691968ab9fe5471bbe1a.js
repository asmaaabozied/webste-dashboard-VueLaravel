(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n#selected[data-v-7ff4f9e4],\n#employees[data-v-7ff4f9e4] {\n  height: 50vh;\n  overflow-y: scroll;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css& ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module exports are unknown */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssignCarToEmp_vue_vue_type_style_index_0_id_7ff4f9e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssignCarToEmp_vue_vue_type_style_index_0_id_7ff4f9e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssignCarToEmp_vue_vue_type_style_index_0_id_7ff4f9e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssignCarToEmp_vue_vue_type_style_index_0_id_7ff4f9e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_AssignCarToEmp_vue_vue_type_style_index_0_id_7ff4f9e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/pages/MaintenanceManager/Cars.vue":
/*!********************************************************************!*\
  !*** ./resources/js/pages/MaintenanceManager/Cars.vue + 9 modules ***!
  \********************************************************************/
/*! exports provided: default */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/@mdi/js/mdi.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vue-loader/lib/runtime/componentNormalizer.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify-loader/lib/runtime/installComponents.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VAutocomplete/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VAvatar/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VBtn/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCard/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VChip/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VDataTable/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VDialog/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VIcon/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VImg/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VList/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VMenu/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VPagination/index.js */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/MaintenanceManager/Cars.vue?vue&type=template&id=7d7630ca&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("h3", [_vm._v(_vm._s(_vm.$t("admin.cars")))]),
      _vm._v(" "),
      _c(
        "v-dialog",
        {
          attrs: { width: "60vw", scrollable: "" },
          model: {
            value: _vm.assignEmpModal,
            callback: function($$v) {
              _vm.assignEmpModal = $$v
            },
            expression: "assignEmpModal"
          }
        },
        [
          _vm.assignEmpModal
            ? _c("assign-car", {
                attrs: { id: _vm.selectedCar },
                on: {
                  success: function($event) {
                    _vm.assignEmpModal = false
                    _vm.load()
                  }
                }
              })
            : _vm._e()
        ],
        1
      ),
      _vm._v(" "),
      _c("v-simple-table", {
        attrs: { dense: "", "fixed-header": "" },
        scopedSlots: _vm._u([
          {
            key: "default",
            fn: function() {
              return [
                _c("thead", [
                  _c("tr", [
                    _c("th", { staticClass: "text-center" }, [_vm._v("#")]),
                    _vm._v(" "),
                    _c("th", { staticClass: "text-center" }, [
                      _vm._v(_vm._s(_vm.$t("general.type")))
                    ]),
                    _vm._v(" "),
                    _c("th", { staticClass: "text-center" }, [
                      _vm._v(_vm._s(_vm.$t("general.no")))
                    ]),
                    _vm._v(" "),
                    _c("th", { staticClass: "text-center" }, [
                      _vm._v(_vm._s(_vm.$t("technical.assignedEmps")))
                    ]),
                    _vm._v(" "),
                    _c("th", { staticClass: "text-center" }, [_vm._v(" ")])
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.items, function(item, i) {
                    return _c("tr", { key: i }, [
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(_vm._s(_vm.items.id))
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(_vm._s(item.car_kind))
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _vm._v(_vm._s(item.palette_number))
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        item.employee_info
                          ? _c(
                              "div",
                              [
                                _c(
                                  "v-chip",
                                  {
                                    attrs: { close: "" },
                                    on: {
                                      "click:close": function($event) {
                                        return _vm.removeCarAssign(
                                          item.employee_info.id
                                        )
                                      }
                                    }
                                  },
                                  [
                                    _c(
                                      "v-avatar",
                                      { attrs: { left: "" } },
                                      [
                                        _c("v-img", {
                                          attrs: {
                                            src: item.employee_info.image
                                          }
                                        })
                                      ],
                                      1
                                    ),
                                    _vm._v(
                                      "\n                " +
                                        _vm._s(item.employee_info.name) +
                                        "\n              "
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          : _vm._e()
                      ]),
                      _vm._v(" "),
                      _c("td", { staticClass: "text-center" }, [
                        _c(
                          "div",
                          { staticClass: "text-center" },
                          [
                            _c(
                              "v-menu",
                              {
                                attrs: { "offset-y": "" },
                                scopedSlots: _vm._u(
                                  [
                                    {
                                      key: "activator",
                                      fn: function(ref) {
                                        var on = ref.on
                                        return [
                                          _c(
                                            "v-btn",
                                            _vm._g(
                                              {
                                                attrs: {
                                                  color: "black",
                                                  icon: "",
                                                  dark: ""
                                                }
                                              },
                                              on
                                            ),
                                            [
                                              _c("v-icon", [
                                                _vm._v(
                                                  _vm._s(
                                                    _vm.icons.mdiDotsVertical
                                                  )
                                                )
                                              ])
                                            ],
                                            1
                                          )
                                        ]
                                      }
                                    }
                                  ],
                                  null,
                                  true
                                )
                              },
                              [
                                _vm._v(" "),
                                _c(
                                  "v-list",
                                  [
                                    _c(
                                      "v-list-item",
                                      {
                                        on: {
                                          click: function($event) {
                                            return _vm.openModal(item.id)
                                          }
                                        }
                                      },
                                      [
                                        _c("v-list-item-title", [
                                          _vm._v(
                                            _vm._s(
                                              _vm.$t("technical.carAssign")
                                            )
                                          )
                                        ])
                                      ],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ],
                              1
                            )
                          ],
                          1
                        )
                      ])
                    ])
                  }),
                  0
                )
              ]
            },
            proxy: true
          }
        ])
      }),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "text-center" },
        [
          _c("v-pagination", {
            attrs: {
              length: Math.ceil(_vm.total / _vm.limit),
              "total-visible": 5,
              circle: ""
            },
            model: {
              value: _vm.page,
              callback: function($$v) {
                _vm.page = $$v
              },
              expression: "page"
            }
          })
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/MaintenanceManager/Cars.vue?vue&type=template&id=7d7630ca&scoped=true&

// EXTERNAL MODULE: ./node_modules/@mdi/js/mdi.js
var mdi = __webpack_require__("./node_modules/@mdi/js/mdi.js");

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=template&id=7ff4f9e4&scoped=true&
var AssignCarToEmpvue_type_template_id_7ff4f9e4_scoped_true_render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-card",
    { attrs: { elevation: "3" } },
    [
      _c("v-card-title", [_vm._v(_vm._s(_vm.$t("technical.assignEmps")))]),
      _vm._v(" "),
      _c(
        "v-card-text",
        { staticClass: "d-flex justify-center flex-column" },
        [
          _c(
            "v-card",
            { attrs: { outlined: "" } },
            [
              _c(
                "v-card-text",
                { attrs: { id: "employees" } },
                [
                  _c("v-autocomplete", {
                    staticClass: "ma-4",
                    attrs: {
                      items: _vm.employees,
                      outlined: "",
                      dense: "",
                      chips: "",
                      "item-text": "name",
                      "item-value": "id",
                      label: _vm.$t("topNav.employees"),
                      clearable: ""
                    },
                    model: {
                      value: _vm.selectedEmp,
                      callback: function($$v) {
                        _vm.selectedEmp = $$v
                      },
                      expression: "selectedEmp"
                    }
                  })
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "v-card-actions",
        { staticClass: "d-flex justify-center" },
        [
          _c(
            "v-btn",
            {
              on: {
                click: function($event) {
                  return _vm.addEmpToWorkshop(_vm.selectedEmp)
                }
              }
            },
            [_vm._v(_vm._s(_vm.$t("general.save")))]
          )
        ],
        1
      )
    ],
    1
  )
}
var AssignCarToEmpvue_type_template_id_7ff4f9e4_scoped_true_staticRenderFns = []
AssignCarToEmpvue_type_template_id_7ff4f9e4_scoped_true_render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=template&id=7ff4f9e4&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var AssignCarToEmpvue_type_script_lang_js_ = ({
  props: {
    id: Number
  },
  data: function data() {
    return {
      icons: {},
      selectedEmp: null,
      employees: []
    };
  },
  methods: {
    load: function load() {
      var _this = this;

      //load all employees
      axios.get("/api/employee").then(function (res) {
        _this.employees = res.data.data;
      })["catch"](function (err) {
        console.warn(err);
      });
    },
    addEmpToWorkshop: function addEmpToWorkshop(empId) {
      var _this2 = this;

      if (this.selectedEmp) axios.post("/api/giveCar", {
        car_id: this.id,
        employee_id: empId
      }).then(function (res) {
        _this2.$notify({
          text: _this2.$t("general.success"),
          type: "success"
        });

        _this2.$emit("success");
      })["catch"](function (err) {
        console.warn(err);
      });
    }
  },
  watch: {
    id: {
      immediate: true,
      handler: function handler(val, oldVal) {
        if (val > 0) this.selectedEmp = null;
      }
    }
  },
  created: function created() {
    this.load();
  }
});
// CONCATENATED MODULE: ./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=script&lang=js&
 /* harmony default export */ var MaintenanceManager_AssignCarToEmpvue_type_script_lang_js_ = (AssignCarToEmpvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&
var AssignCarToEmpvue_type_style_index_0_id_7ff4f9e4_scoped_true_lang_css_ = __webpack_require__("./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue?vue&type=style&index=0&id=7ff4f9e4&scoped=true&lang=css&");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

// EXTERNAL MODULE: ./node_modules/vuetify-loader/lib/runtime/installComponents.js
var installComponents = __webpack_require__("./node_modules/vuetify-loader/lib/runtime/installComponents.js");
var installComponents_default = /*#__PURE__*/__webpack_require__.n(installComponents);

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VAutocomplete/index.js
var VAutocomplete = __webpack_require__("./node_modules/vuetify/lib/components/VAutocomplete/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VBtn/index.js
var VBtn = __webpack_require__("./node_modules/vuetify/lib/components/VBtn/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCard/index.js + 1 modules
var VCard = __webpack_require__("./node_modules/vuetify/lib/components/VCard/index.js");

// CONCATENATED MODULE: ./resources/js/pages/MaintenanceManager/AssignCarToEmp.vue






/* normalize component */

var component = Object(componentNormalizer["default"])(
  MaintenanceManager_AssignCarToEmpvue_type_script_lang_js_,
  AssignCarToEmpvue_type_template_id_7ff4f9e4_scoped_true_render,
  AssignCarToEmpvue_type_template_id_7ff4f9e4_scoped_true_staticRenderFns,
  false,
  null,
  "7ff4f9e4",
  null
  
)

/* vuetify-loader */







installComponents_default()(component, {VAutocomplete: VAutocomplete["VAutocomplete"],VBtn: VBtn["VBtn"],VCard: VCard["VCard"],VCardActions: VCard["VCardActions"],VCardText: VCard["VCardText"],VCardTitle: VCard["VCardTitle"]})


/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/MaintenanceManager/AssignCarToEmp.vue"
/* harmony default export */ var AssignCarToEmp = (component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/MaintenanceManager/Cars.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Carsvue_type_script_lang_js_ = ({
  name: "cars",
  metaInfo: function metaInfo() {
    var locale = this.$i18n.locale;
    return {
      title: locale == "en" ? "Vechiles" : "المركبات"
    };
  },
  components: {
    "assign-car": AssignCarToEmp
  },
  data: function data() {
    return {
      icons: {
        mdiDotsVertical: mdi["mdiDotsVertical"]
      },
      page: 1,
      limit: 5,
      total: 0,
      assignEmpModal: false,
      items: [],
      selectedCar: null
    };
  },
  methods: {
    load: function load() {
      var _this = this;

      axios.get("/api/cars?page=".concat(this.page)).then(function (res) {
        _this.items = res.data.data.resource.data;
        _this.limit = res.data.data.resource.per_page;
        _this.total = res.data.data.resource.total;
      })["catch"](function (err) {
        console.warn(err);
      });
    },
    openModal: function openModal(id) {
      this.selectedCar = id;
      this.assignEmpModal = true;
    },
    removeCarAssign: function removeCarAssign(empId) {
      var _this2 = this;

      axios.post("/api/takeCar", {
        employee_id: empId
      }).then(function (res) {
        _this2.$notify({
          text: _this2.$t("general.success"),
          type: "info"
        });

        _this2.load();
      })["catch"](function (err) {
        console.warn(err);
      });
    }
  },
  created: function created() {
    this.load();
  }
});
// CONCATENATED MODULE: ./resources/js/pages/MaintenanceManager/Cars.vue?vue&type=script&lang=js&
 /* harmony default export */ var MaintenanceManager_Carsvue_type_script_lang_js_ = (Carsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VAvatar/index.js + 1 modules
var VAvatar = __webpack_require__("./node_modules/vuetify/lib/components/VAvatar/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VChip/index.js + 1 modules
var VChip = __webpack_require__("./node_modules/vuetify/lib/components/VChip/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VDialog/index.js
var VDialog = __webpack_require__("./node_modules/vuetify/lib/components/VDialog/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VIcon/index.js
var VIcon = __webpack_require__("./node_modules/vuetify/lib/components/VIcon/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VImg/index.js
var VImg = __webpack_require__("./node_modules/vuetify/lib/components/VImg/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VList/index.js + 7 modules
var VList = __webpack_require__("./node_modules/vuetify/lib/components/VList/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VMenu/index.js + 1 modules
var VMenu = __webpack_require__("./node_modules/vuetify/lib/components/VMenu/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VPagination/index.js + 1 modules
var VPagination = __webpack_require__("./node_modules/vuetify/lib/components/VPagination/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VDataTable/index.js + 13 modules
var VDataTable = __webpack_require__("./node_modules/vuetify/lib/components/VDataTable/index.js");

// CONCATENATED MODULE: ./resources/js/pages/MaintenanceManager/Cars.vue





/* normalize component */

var Cars_component = Object(componentNormalizer["default"])(
  MaintenanceManager_Carsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "7d7630ca",
  null
  
)

/* vuetify-loader */













installComponents_default()(Cars_component, {VAvatar: VAvatar["VAvatar"],VBtn: VBtn["VBtn"],VChip: VChip["VChip"],VDialog: VDialog["VDialog"],VIcon: VIcon["VIcon"],VImg: VImg["VImg"],VList: VList["VList"],VListItem: VList["VListItem"],VListItemTitle: VList["VListItemTitle"],VMenu: VMenu["VMenu"],VPagination: VPagination["VPagination"],VSimpleTable: VDataTable["VSimpleTable"]})


/* hot reload */
if (false) { var Cars_api; }
Cars_component.options.__file = "resources/js/pages/MaintenanceManager/Cars.vue"
/* harmony default export */ var Cars = __webpack_exports__["default"] = (Cars_component.exports);

/***/ })

}]);