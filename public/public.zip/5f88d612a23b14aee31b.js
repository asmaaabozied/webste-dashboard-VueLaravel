(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[4],{

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n#image[data-v-7c9f9ed4] {\n    width: 100%;\n    height: 100%;\n    background-color: gray;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&":
/*!******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css& ***!
  \******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./resources/assets/images/contactUs.svg":
/*!***********************************************!*\
  !*** ./resources/assets/images/contactUs.svg ***!
  \***********************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/contactUs.svg?959097689d7b00e02e3a34411a8f5f8e";

/***/ }),

/***/ "./resources/js/pages/Customer/ContactUs.vue":
/*!***************************************************************!*\
  !*** ./resources/js/pages/Customer/ContactUs.vue + 4 modules ***!
  \***************************************************************/
/*! exports provided: default */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/@mdi/js/mdi.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/axios/index.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vue-loader/lib/runtime/componentNormalizer.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuelidate/lib/validators/index.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify-loader/lib/runtime/installComponents.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VBtn/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCard/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VGrid/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VIcon/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VImg/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VSelect/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VTextarea/index.js */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/ContactUs.vue?vue&type=template&id=7c9f9ed4&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-card",
        [
          _c(
            "v-row",
            { attrs: { "no-gutters": "" } },
            [
              _c("v-col", { attrs: { md: "8", lg: "8", xl: "8" } }, [
                _c("div", { staticClass: "pa-5" }, [
                  _c("h2", [_vm._v(_vm._s(_vm.$t("general.contactUs")))]),
                  _vm._v(" "),
                  _c("br"),
                  _vm._v(" "),
                  _c(
                    "div",
                    [
                      _c("v-icon", { staticClass: "mx-1" }, [
                        _vm._v(_vm._s(_vm.icons.mdiPhone))
                      ]),
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.$t("general.phone")) +
                          "\n                    "
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("br"),
                  _vm._v(" "),
                  _c(
                    "div",
                    [
                      _c("v-icon", { staticClass: "mx-1" }, [
                        _vm._v(_vm._s(_vm.icons.mdiBank))
                      ]),
                      _vm._v(
                        "\n                        " +
                          _vm._s(_vm.$t("general.bankInfo")) +
                          "\n                    "
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("div", { staticClass: "mt-8" }, [
                    _vm._v(_vm._s(_vm.$t("general.sendUs")))
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "mt-2" },
                    [
                      _c("v-textarea", {
                        attrs: {
                          placeholder: _vm.$t("general.suggestion"),
                          "error-messages": _vm.suggestErrors,
                          rounded: "",
                          outlined: "",
                          "no-resize": ""
                        },
                        model: {
                          value: _vm.suggestion,
                          callback: function($$v) {
                            _vm.suggestion = $$v
                          },
                          expression: "suggestion"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    [
                      _c("v-select", {
                        attrs: {
                          "error-messages": _vm.departmentErrors,
                          label: _vm.$t("general.department"),
                          items: _vm.departments,
                          "item-value": "id",
                          "item-text":
                            _vm.$i18n.locale == "ar" ? "name_ar" : "name",
                          rounded: "",
                          outlined: "",
                          dense: ""
                        },
                        model: {
                          value: _vm.department,
                          callback: function($$v) {
                            _vm.department = $$v
                          },
                          expression: "department"
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "d-flex justify-end" },
                    [
                      _vm.$isLoggedin
                        ? _c(
                            "v-btn",
                            {
                              staticClass: "mx-2",
                              attrs: { rounded: "", color: "primary" },
                              on: { click: _vm.send }
                            },
                            [
                              _vm._v(
                                _vm._s(_vm.$t("contactUs.send")) +
                                  "\n                        "
                              )
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      !_vm.$isLoggedin
                        ? _c(
                            "v-btn",
                            {
                              staticClass: "mx-2",
                              attrs: { rounded: "", color: "primary" },
                              on: {
                                click: function($event) {
                                  return _vm.redirectIfNotLoggedIn()
                                }
                              }
                            },
                            [
                              _vm._v(
                                _vm._s(_vm.$t("contactUs.send")) +
                                  "\n                        "
                              )
                            ]
                          )
                        : _vm._e()
                    ],
                    1
                  )
                ])
              ]),
              _vm._v(" "),
              _c(
                "v-col",
                { attrs: { md: "4", lg: "4", xl: "4" } },
                [_c("v-img", { attrs: { height: "85vh", src: _vm.image } })],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/Customer/ContactUs.vue?vue&type=template&id=7c9f9ed4&scoped=true&

// EXTERNAL MODULE: ./node_modules/vuelidate/lib/validators/index.js
var validators = __webpack_require__("./node_modules/vuelidate/lib/validators/index.js");

// EXTERNAL MODULE: ./node_modules/axios/index.js
var axios = __webpack_require__("./node_modules/axios/index.js");
var axios_default = /*#__PURE__*/__webpack_require__.n(axios);

// EXTERNAL MODULE: ./node_modules/@mdi/js/mdi.js
var mdi = __webpack_require__("./node_modules/@mdi/js/mdi.js");

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/ContactUs.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ var ContactUsvue_type_script_lang_js_ = ({
  name: "contactUs",
  metaInfo: function metaInfo() {
    var locale = this.$i18n.locale;
    return {
      title: locale == "en" ? "Contact us" : "اتصل بنا"
    };
  },
  data: function data() {
    return {
      icons: {
        mdiPhone: mdi["mdiPhone"],
        mdiBank: mdi["mdiBank"]
      },
      suggestion: null,
      department: null,
      departments: [],
      image: __webpack_require__(/*! ./../../../assets/images/contactUs.svg */ "./resources/assets/images/contactUs.svg")
    };
  },
  validations: {
    suggestion: {
      required: validators["required"]
    },
    department: {
      required: validators["required"]
    }
  },
  methods: {
    send: function send() {
      var _this = this;

      this.$v.$touch();
      if (this.$v.$invalid) return;
      axios_default.a.post("/api/suggestion", {
        department_id: this.department,
        text: this.suggestion
      }).then(function () {
        _this.$router.push({
          name: "home"
        });
      })["catch"](function () {
        console.warn(err);
      });
    },
    load: function load() {
      var _this2 = this;

      axios_default.a.get("/api/department").then(function (res) {
        _this2.departments = res.data.data.filter(function (item) {
          return item.id != _this2.$store.state.user.department_id;
        });
      })["catch"](function (err) {
        console.warn(err);
      });
    }
  },
  computed: {
    suggestErrors: function suggestErrors() {
      var errors = [];
      if (!this.$v.suggestion.$dirty) return errors;
      !this.$v.suggestion.required && errors.push(this.$t("validate.required"));
      return errors;
    },
    departmentErrors: function departmentErrors() {
      var errors = [];
      if (!this.$v.department.$dirty) return errors;
      !this.$v.department.required && errors.push(this.$t("validate.required"));
      return errors;
    }
  },
  beforeRouteEnter: function beforeRouteEnter(to, from, next) {
    next(function (vm) {
      vm.load();
    });
  }
});
// CONCATENATED MODULE: ./resources/js/pages/Customer/ContactUs.vue?vue&type=script&lang=js&
 /* harmony default export */ var Customer_ContactUsvue_type_script_lang_js_ = (ContactUsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&
var ContactUsvue_type_style_index_0_id_7c9f9ed4_scoped_true_lang_css_ = __webpack_require__("./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

// EXTERNAL MODULE: ./node_modules/vuetify-loader/lib/runtime/installComponents.js
var installComponents = __webpack_require__("./node_modules/vuetify-loader/lib/runtime/installComponents.js");
var installComponents_default = /*#__PURE__*/__webpack_require__.n(installComponents);

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VBtn/index.js
var VBtn = __webpack_require__("./node_modules/vuetify/lib/components/VBtn/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCard/index.js + 1 modules
var VCard = __webpack_require__("./node_modules/vuetify/lib/components/VCard/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VGrid/index.js + 7 modules
var VGrid = __webpack_require__("./node_modules/vuetify/lib/components/VGrid/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VIcon/index.js
var VIcon = __webpack_require__("./node_modules/vuetify/lib/components/VIcon/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VImg/index.js
var VImg = __webpack_require__("./node_modules/vuetify/lib/components/VImg/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VSelect/index.js
var VSelect = __webpack_require__("./node_modules/vuetify/lib/components/VSelect/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VTextarea/index.js + 1 modules
var VTextarea = __webpack_require__("./node_modules/vuetify/lib/components/VTextarea/index.js");

// CONCATENATED MODULE: ./resources/js/pages/Customer/ContactUs.vue






/* normalize component */

var component = Object(componentNormalizer["default"])(
  Customer_ContactUsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "7c9f9ed4",
  null
  
)

/* vuetify-loader */









installComponents_default()(component, {VBtn: VBtn["VBtn"],VCard: VCard["VCard"],VCol: VGrid["VCol"],VIcon: VIcon["VIcon"],VImg: VImg["VImg"],VRow: VGrid["VRow"],VSelect: VSelect["VSelect"],VTextarea: VTextarea["VTextarea"]})


/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Customer/ContactUs.vue"
/* harmony default export */ var ContactUs = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css& ***!
  \************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module exports are unknown */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactUs_vue_vue_type_style_index_0_id_7c9f9ed4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/ContactUs.vue?vue&type=style&index=0&id=7c9f9ed4&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactUs_vue_vue_type_style_index_0_id_7c9f9ed4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactUs_vue_vue_type_style_index_0_id_7c9f9ed4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactUs_vue_vue_type_style_index_0_id_7c9f9ed4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ContactUs_vue_vue_type_style_index_0_id_7c9f9ed4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ })

}]);