(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[12],{

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.text-h1[data-v-089062e4],\n.text-h2[data-v-089062e4],\n.text-h3[data-v-089062e4],\n.text-h4[data-v-089062e4],\n.text-h5[data-v-089062e4],\n.text-h6[data-v-089062e4],\n.text-lg-h5[data-v-089062e4],\n.text-body-1[data-v-089062e4] {\n  font-family: unset !important;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./resources/assets/images/customerPortal/orders.jpg":
/*!***********************************************************!*\
  !*** ./resources/assets/images/customerPortal/orders.jpg ***!
  \***********************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/orders.jpg?61b0285c6215368ca5dcf2ede6b74ed7";

/***/ }),

/***/ "./resources/assets/images/customerPortal/payment.jpg":
/*!************************************************************!*\
  !*** ./resources/assets/images/customerPortal/payment.jpg ***!
  \************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/payment.jpg?d7fe5a74fcb75b27e80f49e35fb638ac";

/***/ }),

/***/ "./resources/assets/images/customerPortal/products.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/customerPortal/products.jpg ***!
  \*************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/products.jpg?75d9893d0f6da047b7b2830ddb3f5ca6";

/***/ }),

/***/ "./resources/assets/images/customerPortal/services.jpg":
/*!*************************************************************!*\
  !*** ./resources/assets/images/customerPortal/services.jpg ***!
  \*************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/services.jpg?584595c877eb97e6f3a88fcd5fc508e7";

/***/ }),

/***/ "./resources/js/pages/Customer/Portal.vue":
/*!************************************************************!*\
  !*** ./resources/js/pages/Customer/Portal.vue + 4 modules ***!
  \************************************************************/
/*! exports provided: default */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vue-loader/lib/runtime/componentNormalizer.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify-loader/lib/runtime/installComponents.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VBtn/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCard/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCarousel/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VGrid/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VHover/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VImg/index.js */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/Portal.vue?vue&type=template&id=089062e4&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("v-row", { staticClass: "my-1", attrs: { justify: "center" } }, [
        _c(
          "div",
          { staticClass: "ad-container", staticStyle: { width: "1000px" } },
          [
            _c(
              "v-carousel",
              {
                attrs: {
                  height: "100%",
                  cycle: "",
                  "hide-delimiters": "",
                  "show-arrows": false
                }
              },
              _vm._l(_vm.internalAds, function(item, i) {
                return _c("v-carousel-item", {
                  key: i,
                  attrs: { src: item.image }
                })
              }),
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "text-center text-h5" }, [
        _vm._v(
          "\n    " +
            _vm._s(_vm.$t("general.welcome") + _vm.$store.state.user.userName) +
            "\n  "
        )
      ]),
      _vm._v(" "),
      _c(
        "v-row",
        { staticClass: "my-3 mx-16", attrs: { justify: "center" } },
        _vm._l(_vm.items, function(item, i) {
          return _c(
            "v-col",
            {
              key: i,
              staticClass: "d-flex justify-center",
              attrs: { cols: "12", md: "6", xl: "6" }
            },
            [
              _c("v-hover", {
                attrs: { "open-delay": "200" },
                scopedSlots: _vm._u(
                  [
                    {
                      key: "default",
                      fn: function(ref) {
                        var hover = ref.hover
                        return [
                          _c(
                            "v-col",
                            { attrs: { cols: "12", md: "10", xl: "8" } },
                            [
                              _c(
                                "v-card",
                                {
                                  staticClass: "rounded",
                                  staticStyle: { overflow: "hidden" },
                                  attrs: { elevation: hover ? 10 : 4 }
                                },
                                [
                                  _c(
                                    "router-link",
                                    { attrs: { to: { name: item.to } } },
                                    [
                                      _c("v-img", {
                                        attrs: {
                                          height: "15rem",
                                          src: item.img
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "v-card-actions",
                                    { staticClass: "d-flex justify-center" },
                                    [
                                      _c(
                                        "v-btn",
                                        {
                                          staticClass: "text-h6",
                                          attrs: {
                                            text: "",
                                            to: { name: item.to }
                                          }
                                        },
                                        [_vm._v(" " + _vm._s(item.label) + " ")]
                                      )
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ]
                      }
                    }
                  ],
                  null,
                  true
                )
              })
            ],
            1
          )
        }),
        1
      ),
      _vm._v(" "),
      _c("v-row", { staticClass: "my-1", attrs: { justify: "center" } }, [
        _c("div", { staticClass: "ad-container" })
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/Customer/Portal.vue?vue&type=template&id=089062e4&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/Portal.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var Portalvue_type_script_lang_js_ = ({
  name: "customer-portal",
  metaInfo: function metaInfo() {
    var locale = this.$i18n.locale;
    return {
      title: locale == "en" ? "My portal" : "مكتبي"
    };
  },
  data: function data() {
    return {
      internalAds: [],
      items: [{
        img: __webpack_require__(/*! ./../../../assets/images/customerPortal/services.jpg */ "./resources/assets/images/customerPortal/services.jpg"),
        label: this.$t("topNav.ourServices"),
        to: "c6"
      }, {
        img: __webpack_require__(/*! ./../../../assets/images/customerPortal/products.jpg */ "./resources/assets/images/customerPortal/products.jpg"),
        label: this.$t("home.shopProducts"),
        to: "c13"
      }, {
        img: __webpack_require__(/*! ./../../../assets/images/customerPortal/orders.jpg */ "./resources/assets/images/customerPortal/orders.jpg"),
        label: this.$t("myRequests.myRequests"),
        to: "c2"
      }, {
        img: __webpack_require__(/*! ./../../../assets/images/customerPortal/payment.jpg */ "./resources/assets/images/customerPortal/payment.jpg"),
        label: this.$t("transactions.transactions"),
        to: "c19"
      }]
    };
  },
  methods: {
    load: function load() {
      var _this = this;

      axios.get("/api/advertArea").then(function (res) {
        _this.internalAds = res.data.data.resource.data;
      })["catch"](function (err) {
        console.warn(err);
      });
    }
  },
  created: function created() {
    this.load();
  }
});
// CONCATENATED MODULE: ./resources/js/pages/Customer/Portal.vue?vue&type=script&lang=js&
 /* harmony default export */ var Customer_Portalvue_type_script_lang_js_ = (Portalvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&
var Portalvue_type_style_index_0_id_089062e4_scoped_true_lang_css_ = __webpack_require__("./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

// EXTERNAL MODULE: ./node_modules/vuetify-loader/lib/runtime/installComponents.js
var installComponents = __webpack_require__("./node_modules/vuetify-loader/lib/runtime/installComponents.js");
var installComponents_default = /*#__PURE__*/__webpack_require__.n(installComponents);

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VBtn/index.js
var VBtn = __webpack_require__("./node_modules/vuetify/lib/components/VBtn/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCard/index.js + 1 modules
var VCard = __webpack_require__("./node_modules/vuetify/lib/components/VCard/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCarousel/index.js + 2 modules
var VCarousel = __webpack_require__("./node_modules/vuetify/lib/components/VCarousel/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VGrid/index.js + 7 modules
var VGrid = __webpack_require__("./node_modules/vuetify/lib/components/VGrid/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VHover/index.js + 1 modules
var VHover = __webpack_require__("./node_modules/vuetify/lib/components/VHover/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VImg/index.js
var VImg = __webpack_require__("./node_modules/vuetify/lib/components/VImg/index.js");

// CONCATENATED MODULE: ./resources/js/pages/Customer/Portal.vue






/* normalize component */

var component = Object(componentNormalizer["default"])(
  Customer_Portalvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "089062e4",
  null
  
)

/* vuetify-loader */










installComponents_default()(component, {VBtn: VBtn["VBtn"],VCard: VCard["VCard"],VCardActions: VCard["VCardActions"],VCarousel: VCarousel["VCarousel"],VCarouselItem: VCarousel["VCarouselItem"],VCol: VGrid["VCol"],VHover: VHover["VHover"],VImg: VImg["VImg"],VRow: VGrid["VRow"]})


/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Customer/Portal.vue"
/* harmony default export */ var Portal = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css& ***!
  \*********************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module exports are unknown */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Portal_vue_vue_type_style_index_0_id_089062e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader!../../../../node_modules/css-loader??ref--6-1!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src??ref--6-2!../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/Portal.vue?vue&type=style&index=0&id=089062e4&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Portal_vue_vue_type_style_index_0_id_089062e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Portal_vue_vue_type_style_index_0_id_089062e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Portal_vue_vue_type_style_index_0_id_089062e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Portal_vue_vue_type_style_index_0_id_089062e4_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ })

}]);