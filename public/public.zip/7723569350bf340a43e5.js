(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[11],{

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css& ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.b-btn[data-v-0fb92822] {\n    width: 150px;\n    border-radius: 10px;\n    background: #93d98f;\n    color: white;\n    box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.15);\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "\n.b-section[data-v-2dbae867] {\n  box-shadow: 0 0 15px 0 rgba(0, 0, 0, 0.15);\n  border-radius: 15px;\n}\n.b-container[data-v-2dbae867] {\n  display: flex;\n  flex-wrap: wrap;\n  width: auto;\n  justify-content: center;\n}\n", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css& ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../node_modules/css-loader??ref--6-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader??ref--6-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-2!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../node_modules/css-loader??ref--6-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css& */ "./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./resources/assets/images/1.png":
/*!***************************************!*\
  !*** ./resources/assets/images/1.png ***!
  \***************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/1.png?a300989434f35637d6778d679bb68d91";

/***/ }),

/***/ "./resources/assets/images/2.png":
/*!***************************************!*\
  !*** ./resources/assets/images/2.png ***!
  \***************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/2.png?46f178e188d09a60add35c64765c1fe4";

/***/ }),

/***/ "./resources/assets/images/3.png":
/*!***************************************!*\
  !*** ./resources/assets/images/3.png ***!
  \***************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/3.png?3ef4af74c17c4ce4be23d001d426f0e2";

/***/ }),

/***/ "./resources/assets/images/4.png":
/*!***************************************!*\
  !*** ./resources/assets/images/4.png ***!
  \***************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/4.png?64e80ada48e4734246abdf313fcc1053";

/***/ }),

/***/ "./resources/assets/images/6.png":
/*!***************************************!*\
  !*** ./resources/assets/images/6.png ***!
  \***************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/6.png?53ff89e9b1ad215cd29384d110624ee2";

/***/ }),

/***/ "./resources/assets/images/7.png":
/*!***************************************!*\
  !*** ./resources/assets/images/7.png ***!
  \***************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */
/***/ (function(module, exports) {

module.exports = "/images/7.png?bf3d2da570cb1674589a49fa1231b6ac";

/***/ }),

/***/ "./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&":
/*!***********************************************************************************************************************!*\
  !*** ./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css& ***!
  \***********************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module exports are unknown */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ServiceItem_vue_vue_type_style_index_0_id_0fb92822_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader!../../../../../node_modules/css-loader??ref--6-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ServiceItem_vue_vue_type_style_index_0_id_0fb92822_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ServiceItem_vue_vue_type_style_index_0_id_0fb92822_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ServiceItem_vue_vue_type_style_index_0_id_0fb92822_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ServiceItem_vue_vue_type_style_index_0_id_0fb92822_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/pages/Customer/services/Services.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/pages/Customer/services/Services.vue + 9 modules ***!
  \***********************************************************************/
/*! exports provided: default */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vue-loader/lib/runtime/componentNormalizer.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify-loader/lib/runtime/installComponents.js (<- Module is not an ECMAScript module) */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VBtn/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VCard/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VImg/index.js */
/*! ModuleConcatenation bailout: Cannot concat with ./node_modules/vuetify/lib/components/VRating/index.js */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/Services.vue?vue&type=template&id=2dbae867&scoped=true&
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "b-section b-back ma-5" }, [
    _c("div", { staticClass: "pa-4" }, [
      _c(
        "h3",
        { staticClass: "m-0", class: { "text-right": _vm.$vuetify.rtl } },
        [_vm._v(_vm._s(_vm.$t("services.inmaServicesSection")))]
      )
    ]),
    _vm._v(" "),
    _c("div", { staticClass: "pa-3" }, [
      _c(
        "div",
        { staticClass: "b-container" },
        _vm._l(_vm.items, function(item) {
          return _c("service-item", {
            key: item.id,
            staticClass: "ma-4",
            attrs: { item: item }
          })
        }),
        1
      )
    ])
  ])
}
var staticRenderFns = []
render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/Customer/services/Services.vue?vue&type=template&id=2dbae867&scoped=true&

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=template&id=0fb92822&scoped=true&
var ServiceItemvue_type_template_id_0fb92822_scoped_true_render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "v-card",
        {
          staticClass: "rounded-lg",
          staticStyle: { height: "350px" },
          attrs: { width: "25vw" }
        },
        [
          _c("v-img", { attrs: { height: "20vh", src: _vm.$props.item.img } }),
          _vm._v(" "),
          _c("v-card-title", [_vm._v(_vm._s(_vm.$props.item.title))]),
          _vm._v(" "),
          _c("v-card-text", [_vm._v(_vm._s(_vm.$props.item.description))]),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "text-center" },
            [
              _c("v-rating", {
                attrs: {
                  readonly: "",
                  color: "yellow darken-3",
                  "background-color": "grey darken-1"
                },
                model: {
                  value: _vm.$props.item.rating,
                  callback: function($$v) {
                    _vm.$set(_vm.$props.item, "rating", $$v)
                  },
                  expression: "$props.item.rating"
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "v-card-actions",
            { staticClass: "d-flex justify-center" },
            [
              _vm.$isLoggedin
                ? _c(
                    "v-btn",
                    {
                      attrs: {
                        to: { name: _vm.$props.item.link, params: { id: 0 } },
                        color: "orange",
                        text: ""
                      }
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.$t("request.orderThis")) +
                          "\n            "
                      )
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              !_vm.$isLoggedin
                ? _c(
                    "v-btn",
                    {
                      attrs: { color: "orange", text: "" },
                      on: {
                        click: function($event) {
                          return _vm.redirectIfNotLoggedIn()
                        }
                      }
                    },
                    [
                      _vm._v(
                        "\n                " +
                          _vm._s(_vm.$t("request.orderThis")) +
                          "\n            "
                      )
                    ]
                  )
                : _vm._e()
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var ServiceItemvue_type_template_id_0fb92822_scoped_true_staticRenderFns = []
ServiceItemvue_type_template_id_0fb92822_scoped_true_render._withStripped = true


// CONCATENATED MODULE: ./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=template&id=0fb92822&scoped=true&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var ServiceItemvue_type_script_lang_js_ = ({
  name: "service-item",
  props: ["item"],
  data: function data() {
    return {};
  },
  methods: {
    "goto": function goto(link) {
      this.$router.push({
        name: link
      });
    }
  }
});
// CONCATENATED MODULE: ./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=script&lang=js&
 /* harmony default export */ var services_ServiceItemvue_type_script_lang_js_ = (ServiceItemvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&
var ServiceItemvue_type_style_index_0_id_0fb92822_scoped_true_lang_css_ = __webpack_require__("./resources/js/pages/Customer/services/ServiceItem.vue?vue&type=style&index=0&id=0fb92822&scoped=true&lang=css&");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

// EXTERNAL MODULE: ./node_modules/vuetify-loader/lib/runtime/installComponents.js
var installComponents = __webpack_require__("./node_modules/vuetify-loader/lib/runtime/installComponents.js");
var installComponents_default = /*#__PURE__*/__webpack_require__.n(installComponents);

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VBtn/index.js
var VBtn = __webpack_require__("./node_modules/vuetify/lib/components/VBtn/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VCard/index.js + 1 modules
var VCard = __webpack_require__("./node_modules/vuetify/lib/components/VCard/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VImg/index.js
var VImg = __webpack_require__("./node_modules/vuetify/lib/components/VImg/index.js");

// EXTERNAL MODULE: ./node_modules/vuetify/lib/components/VRating/index.js + 1 modules
var VRating = __webpack_require__("./node_modules/vuetify/lib/components/VRating/index.js");

// CONCATENATED MODULE: ./resources/js/pages/Customer/services/ServiceItem.vue






/* normalize component */

var component = Object(componentNormalizer["default"])(
  services_ServiceItemvue_type_script_lang_js_,
  ServiceItemvue_type_template_id_0fb92822_scoped_true_render,
  ServiceItemvue_type_template_id_0fb92822_scoped_true_staticRenderFns,
  false,
  null,
  "0fb92822",
  null
  
)

/* vuetify-loader */








installComponents_default()(component, {VBtn: VBtn["VBtn"],VCard: VCard["VCard"],VCardActions: VCard["VCardActions"],VCardText: VCard["VCardText"],VCardTitle: VCard["VCardTitle"],VImg: VImg["VImg"],VRating: VRating["VRating"]})


/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/pages/Customer/services/ServiceItem.vue"
/* harmony default export */ var ServiceItem = (component.exports);
// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vuetify-loader/lib/loader.js??ref--11-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/pages/Customer/services/Services.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var Servicesvue_type_script_lang_js_ = ({
  components: {
    ServiceItem: ServiceItem
  },
  data: function data() {
    return {
      items: [{
        id: 1,
        title: this.$t("services.srv01.title"),
        description: this.$t("services.srv01.desc"),
        img: __webpack_require__(/*! ./../../../../assets/images/4.png */ "./resources/assets/images/4.png"),
        link: "choose-order-type",
        rating: 0
      }, {
        id: 2,
        title: this.$t("services.srv02.title"),
        description: this.$t("services.srv02.desc"),
        img: __webpack_require__(/*! ./../../../../assets/images/7.png */ "./resources/assets/images/7.png"),
        link: "c9",
        rating: 0
      }, {
        id: 3,
        title: this.$t("services.srv03.title"),
        description: this.$t("services.srv03.desc"),
        img: __webpack_require__(/*! ./../../../../assets/images/3.png */ "./resources/assets/images/3.png"),
        link: "c12",
        rating: 0
      }, {
        id: 4,
        title: this.$t("services.srv04.title"),
        description: this.$t("services.srv04.desc"),
        img: __webpack_require__(/*! ./../../../../assets/images/2.png */ "./resources/assets/images/2.png"),
        link: 'c11',
        rating: 0
      }, {
        id: 5,
        title: this.$t("services.srv05.title"),
        description: this.$t("services.srv05.desc"),
        img: __webpack_require__(/*! ./../../../../assets/images/6.png */ "./resources/assets/images/6.png"),
        link: "c22",
        rating: 0
      }, {
        id: 6,
        title: this.$t("services.srv06.title"),
        description: this.$t("services.srv06.desc"),
        img: __webpack_require__(/*! ./../../../../assets/images/1.png */ "./resources/assets/images/1.png"),
        link: "c16",
        rating: 0
      }]
    };
  },
  mounted: function mounted() {
    var _this = this;

    axios.get('/api/getServicesType').then(function (_ref) {
      var data = _ref.data;

      _this.setRating(data.data);
    });
  },
  methods: {
    setRating: function setRating(data) {
      this.items[0].rating = data.maintenance_order;
      this.items[1].rating = data.installment_order;
      this.items[2].rating = data.prevention_maintenance_order;
      this.items[3].rating = data.consultant_order;
      this.items[4].rating = data.order_review_order;
      this.items[5].rating = data.job_application_order;
    }
  }
});
// CONCATENATED MODULE: ./resources/js/pages/Customer/services/Services.vue?vue&type=script&lang=js&
 /* harmony default export */ var services_Servicesvue_type_script_lang_js_ = (Servicesvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&
var Servicesvue_type_style_index_0_id_2dbae867_scoped_true_lang_css_ = __webpack_require__("./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&");

// CONCATENATED MODULE: ./resources/js/pages/Customer/services/Services.vue






/* normalize component */

var Services_component = Object(componentNormalizer["default"])(
  services_Servicesvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "2dbae867",
  null
  
)

/* hot reload */
if (false) { var Services_api; }
Services_component.options.__file = "resources/js/pages/Customer/services/Services.vue"
/* harmony default export */ var Services = __webpack_exports__["default"] = (Services_component.exports);

/***/ }),

/***/ "./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&":
/*!********************************************************************************************************************!*\
  !*** ./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css& ***!
  \********************************************************************************************************************/
/*! no static exports found */
/*! ModuleConcatenation bailout: Module exports are unknown */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Services_vue_vue_type_style_index_0_id_2dbae867_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/style-loader!../../../../../node_modules/css-loader??ref--6-1!../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../node_modules/postcss-loader/src??ref--6-2!../../../../../node_modules/vuetify-loader/lib/loader.js??ref--11-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/vuetify-loader/lib/loader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/pages/Customer/services/Services.vue?vue&type=style&index=0&id=2dbae867&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Services_vue_vue_type_style_index_0_id_2dbae867_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Services_vue_vue_type_style_index_0_id_2dbae867_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Services_vue_vue_type_style_index_0_id_2dbae867_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_ref_6_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_6_2_node_modules_vuetify_loader_lib_loader_js_ref_11_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Services_vue_vue_type_style_index_0_id_2dbae867_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ })

}]);